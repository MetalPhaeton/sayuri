var structSayuri_1_1SetScore_3_01GenMoveType_1_1CAPTURE_01_4 =
[
    [ "F", "structSayuri_1_1SetScore_3_01GenMoveType_1_1CAPTURE_01_4.html#a1fdd8f5896ad3844e16f17fd1d88c395", null ]
];