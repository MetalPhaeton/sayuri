var structSayuri_1_1DoNMR_3_01NodeType_1_1NON__PV_01_4 =
[
    [ "F", "structSayuri_1_1DoNMR_3_01NodeType_1_1NON__PV_01_4.html#a2d2798e07d5235a1a5f8a3ee899aa904", null ]
];