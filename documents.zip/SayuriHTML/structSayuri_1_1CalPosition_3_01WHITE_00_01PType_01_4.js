var structSayuri_1_1CalPosition_3_01WHITE_00_01PType_01_4 =
[
    [ "F", "structSayuri_1_1CalPosition_3_01WHITE_00_01PType_01_4.html#a5f691e121ee532596628b8b022c1a2bd", null ]
];