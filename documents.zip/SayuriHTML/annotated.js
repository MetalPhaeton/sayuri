var annotated =
[
    [ "Sayuri", "namespaceSayuri.html", "namespaceSayuri" ]
];