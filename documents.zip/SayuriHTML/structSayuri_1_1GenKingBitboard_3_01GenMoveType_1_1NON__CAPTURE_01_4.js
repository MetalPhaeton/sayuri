var structSayuri_1_1GenKingBitboard_3_01GenMoveType_1_1NON__CAPTURE_01_4 =
[
    [ "F", "structSayuri_1_1GenKingBitboard_3_01GenMoveType_1_1NON__CAPTURE_01_4.html#acd22c2e15aa97c90f500b1cd27ef438a", null ]
];