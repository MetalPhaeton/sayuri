var structSayuri_1_1GenBitboards_3_01PSide_00_01BISHOP_01_4 =
[
    [ "F", "structSayuri_1_1GenBitboards_3_01PSide_00_01BISHOP_01_4.html#aa7508306a8f40d7bc8db015af36a043e", null ]
];