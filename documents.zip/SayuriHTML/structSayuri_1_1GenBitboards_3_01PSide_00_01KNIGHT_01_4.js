var structSayuri_1_1GenBitboards_3_01PSide_00_01KNIGHT_01_4 =
[
    [ "F", "structSayuri_1_1GenBitboards_3_01PSide_00_01KNIGHT_01_4.html#aa813e9a85fa3ddbee51a7941006e5aae", null ]
];