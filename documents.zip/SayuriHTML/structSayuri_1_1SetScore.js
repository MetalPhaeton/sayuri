var structSayuri_1_1SetScore =
[
    [ "F", "structSayuri_1_1SetScore.html#a05560634ece98e5e55a77c10aa6231db", null ]
];