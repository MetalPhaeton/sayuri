var structSayuri_1_1GenKingBitboard_3_01GenMoveType_1_1CAPTURE_01_4 =
[
    [ "F", "structSayuri_1_1GenKingBitboard_3_01GenMoveType_1_1CAPTURE_01_4.html#a657463b60c283c23552b7ef0023ec067", null ]
];