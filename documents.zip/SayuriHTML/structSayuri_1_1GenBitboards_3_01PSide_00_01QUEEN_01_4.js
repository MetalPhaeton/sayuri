var structSayuri_1_1GenBitboards_3_01PSide_00_01QUEEN_01_4 =
[
    [ "F", "structSayuri_1_1GenBitboards_3_01PSide_00_01QUEEN_01_4.html#aab822a81bd84148c18275b44d0bcb71f", null ]
];