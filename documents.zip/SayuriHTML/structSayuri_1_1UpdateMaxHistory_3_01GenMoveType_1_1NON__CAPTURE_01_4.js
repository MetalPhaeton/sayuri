var structSayuri_1_1UpdateMaxHistory_3_01GenMoveType_1_1NON__CAPTURE_01_4 =
[
    [ "F", "structSayuri_1_1UpdateMaxHistory_3_01GenMoveType_1_1NON__CAPTURE_01_4.html#a97df88bdbf34b9c21a6453fe135de1ba", null ]
];