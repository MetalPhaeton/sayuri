var structSayuri_1_1GenPieceBitboard_3_01GenMoveType_1_1NON__CAPTURE_01_4 =
[
    [ "F", "structSayuri_1_1GenPieceBitboard_3_01GenMoveType_1_1NON__CAPTURE_01_4.html#aa07b81c6331f6f2d80962e438760b91a", null ]
];