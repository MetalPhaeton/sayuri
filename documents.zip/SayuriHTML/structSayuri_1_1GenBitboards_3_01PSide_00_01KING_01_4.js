var structSayuri_1_1GenBitboards_3_01PSide_00_01KING_01_4 =
[
    [ "F", "structSayuri_1_1GenBitboards_3_01PSide_00_01KING_01_4.html#a668a2d24adea60f166ebb02a8e838407", null ]
];