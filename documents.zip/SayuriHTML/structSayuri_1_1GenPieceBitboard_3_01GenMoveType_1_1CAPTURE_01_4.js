var structSayuri_1_1GenPieceBitboard_3_01GenMoveType_1_1CAPTURE_01_4 =
[
    [ "F", "structSayuri_1_1GenPieceBitboard_3_01GenMoveType_1_1CAPTURE_01_4.html#af008f59d089ddcfec6f19af84e13113a", null ]
];