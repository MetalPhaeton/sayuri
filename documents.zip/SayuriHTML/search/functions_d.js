var searchData=
[
  ['nmr_5flimit_5fdepth',['nmr_limit_depth',['../classSayuri_1_1SearchParams.html#ae713e0afe8b51fe9e8242aa124412973',1,'Sayuri::SearchParams::nmr_limit_depth() const '],['../classSayuri_1_1SearchParams.html#a57340dc0c3b6d33969d32b0d731998d8',1,'Sayuri::SearchParams::nmr_limit_depth(int depth)']]],
  ['nmr_5freduction',['nmr_reduction',['../classSayuri_1_1SearchParams.html#a8826d85d7a7be1964fb22ad4e39094bc',1,'Sayuri::SearchParams::nmr_reduction() const '],['../classSayuri_1_1SearchParams.html#adabe40b0bf82420e32d04a44af9b9bfe',1,'Sayuri::SearchParams::nmr_reduction(int reduction)']]],
  ['nmr_5fsearch_5freduction',['nmr_search_reduction',['../classSayuri_1_1SearchParams.html#a57fce5f9c57512bff5bb413da6d08124',1,'Sayuri::SearchParams::nmr_search_reduction() const '],['../classSayuri_1_1SearchParams.html#aeab151e3d3d90219663c4af0d8fad6de',1,'Sayuri::SearchParams::nmr_search_reduction(int reduction)']]],
  ['notifybetacut',['NotifyBetaCut',['../classSayuri_1_1Job.html#a2fc3720d4eeddf83a6077c7c7c2a6679',1,'Sayuri::Job']]]
];
