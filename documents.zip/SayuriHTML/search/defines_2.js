var searchData=
[
  ['max',['MAX',['../chess__util_8h.html#afa99ec4acc4ecb2dc3c2d05da15d0e3f',1,'chess_util.h']]],
  ['min',['MIN',['../chess__util_8h.html#a3acffbd305ee72dcd4593c0d8af64a4f',1,'chess_util.h']]]
];
