var searchData=
[
  ['next',['NEXT',['../chess__def_8h.html#ad74f20db59de819e80bfe34e6eaf60b3',1,'chess_def.h']]]
];
