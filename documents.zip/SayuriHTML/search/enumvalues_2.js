var searchData=
[
  ['capture',['CAPTURE',['../namespaceSayuri.html#a38eace0fcb969cf644905fc3ff641791ab72f08e0732365cac9599b5c42157bf9',1,'Sayuri']]]
];
