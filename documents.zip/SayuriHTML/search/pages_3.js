var searchData=
[
  ['sayuri_20_2d_20uci用チェスエンジン',['Sayuri - UCI用チェスエンジン',['../index.html',1,'']]],
  ['sayuri_20_2d_20静的ライブラリとしての利用法',['Sayuri - 静的ライブラリとしての利用法',['../md_use_as_static_library.html',1,'']]]
];
