var searchData=
[
  ['r_5frot135',['R_ROT135',['../classSayuri_1_1Util.html#a98f0c29fe8c72ac649d7d9c46355962e',1,'Sayuri::Util']]],
  ['r_5frot45',['R_ROT45',['../classSayuri_1_1Util.html#a25f2ca3eae8f0ebac84751b91614fca2',1,'Sayuri::Util']]],
  ['r_5frot90',['R_ROT90',['../classSayuri_1_1Util.html#ae5cabc6285e48d12d52babf2feaa06b0',1,'Sayuri::Util']]],
  ['rank',['RANK',['../classSayuri_1_1Util.html#a9218a8567160908a62dc11806d5f9968',1,'Sayuri::Util']]],
  ['record_5fptr_5f',['record_ptr_',['../classSayuri_1_1Job.html#a818e9dafd8ef7df0b0690dc6bc4be779',1,'Sayuri::Job']]],
  ['record_5ftable_5f',['record_table_',['../classSayuri_1_1ChessEngine.html#a0147ab9a70bedec5c6b79deaceff7352',1,'Sayuri::ChessEngine']]],
  ['rook_5fmove_5f',['rook_move_',['../classSayuri_1_1Util.html#a168ff5f4451090533cfe3eb5855eaedc',1,'Sayuri::Util']]],
  ['rook_5fopen_5ffyle',['ROOK_OPEN_FYLE',['../classSayuri_1_1Evaluator.html#ab4bb831c7ea6628b63224267169aa445',1,'Sayuri::Evaluator']]],
  ['rook_5fpair',['ROOK_PAIR',['../classSayuri_1_1Evaluator.html#a50de1aac209145230737c1a015949381',1,'Sayuri::Evaluator']]],
  ['rook_5fsemiopen_5ffyle',['ROOK_SEMIOPEN_FYLE',['../classSayuri_1_1Evaluator.html#ad48f2cac5fab52b1fc6257fc8e1e1a2c',1,'Sayuri::Evaluator']]],
  ['rot135',['ROT135',['../classSayuri_1_1Util.html#afffe5ec0a4fbf58f49355a9b090c3da6',1,'Sayuri::Util']]],
  ['rot45',['ROT45',['../classSayuri_1_1Util.html#a50594ebe9ca8ec24eb116cf4ddab1d53',1,'Sayuri::Util']]],
  ['rot90',['ROT90',['../classSayuri_1_1Util.html#afd92419a868f38d9a51b7262f1c16b67',1,'Sayuri::Util']]]
];
