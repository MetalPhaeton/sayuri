var searchData=
[
  ['queen',['QUEEN',['../namespaceSayuri.html#a4cdc371480d87aa631fec2bf1318d696',1,'Sayuri']]],
  ['queen_5fmove_5f',['queen_move_',['../classSayuri_1_1Util.html#ac7c47fdad2a473f633f7f7359c269d43',1,'Sayuri::Util']]]
];
