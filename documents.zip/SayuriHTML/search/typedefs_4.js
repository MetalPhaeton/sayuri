var searchData=
[
  ['move',['Move',['../namespaceSayuri.html#adfbeb3ac7256015600cf6befea2c0212',1,'Sayuri']]],
  ['movetype',['MoveType',['../namespaceSayuri.html#a3f44bc167bb599806de18441c4b94f4b',1,'Sayuri']]]
];
