var searchData=
[
  ['addorsub',['AddOrSub',['../structSayuri_1_1AddOrSub.html',1,'Sayuri']]],
  ['addorsub_3c_20black_20_3e',['AddOrSub&lt; BLACK &gt;',['../structSayuri_1_1AddOrSub_3_01BLACK_01_4.html',1,'Sayuri']]],
  ['addorsub_3c_20white_20_3e',['AddOrSub&lt; WHITE &gt;',['../structSayuri_1_1AddOrSub_3_01WHITE_01_4.html',1,'Sayuri']]]
];
