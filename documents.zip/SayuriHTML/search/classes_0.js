var searchData=
[
  ['chessengine',['ChessEngine',['../classSayuri_1_1ChessEngine.html',1,'Sayuri']]],
  ['commandfunction',['CommandFunction',['../structSayuri_1_1UCICommand_1_1CommandFunction.html',1,'Sayuri::UCICommand']]]
];
