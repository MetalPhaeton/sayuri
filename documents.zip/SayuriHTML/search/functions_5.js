var searchData=
[
  ['fen',['FEN',['../classSayuri_1_1FEN.html#aded351aeb7a2b4c153c69821a7aa9488',1,'Sayuri::FEN::FEN(const std::string fen_str)'],['../classSayuri_1_1FEN.html#ac2b55fde6c7c3e7c88d703f66b843759',1,'Sayuri::FEN::FEN()'],['../classSayuri_1_1FEN.html#af8f364a54ffdb5282fda1faf551e5f64',1,'Sayuri::FEN::FEN(const FEN &amp;fen)'],['../classSayuri_1_1FEN.html#a277288202b0ee8eac7651a421334f44f',1,'Sayuri::FEN::FEN(FEN &amp;&amp;fen)']]],
  ['finishmyjob',['FinishMyJob',['../classSayuri_1_1Job.html#af4fe5ed6ef3bc4e62c26c03d20febef6',1,'Sayuri::Job']]],
  ['futility_5fpruning_5fdepth',['futility_pruning_depth',['../classSayuri_1_1SearchParams.html#a80c8a17ac6604ca5dba338937bd611ed',1,'Sayuri::SearchParams::futility_pruning_depth() const '],['../classSayuri_1_1SearchParams.html#ad402d8be66f4f86e1ed7d034b95d24cc',1,'Sayuri::SearchParams::futility_pruning_depth(int depth)']]],
  ['futility_5fpruning_5fmargin',['futility_pruning_margin',['../classSayuri_1_1SearchParams.html#acb13a5022b7206c2bd077c025d6451be',1,'Sayuri::SearchParams::futility_pruning_margin() const '],['../classSayuri_1_1SearchParams.html#a45b846b764865ce0d2586359593c0f4a',1,'Sayuri::SearchParams::futility_pruning_margin(int margin)']]]
];
