var searchData=
[
  ['add',['Add',['../classSayuri_1_1TranspositionTable.html#a7be71ee1c0ac1896e45f14abb91f1757',1,'Sayuri::TranspositionTable::Add()'],['../classSayuri_1_1UCICommand.html#a378c5d21281e90a3db1dbe28acfc46da',1,'Sayuri::UCICommand::Add()']]],
  ['addnotifier',['AddNotifier',['../classSayuri_1_1Job.html#a64d0656ce7828f2fe120b65cb97223fe',1,'Sayuri::Job']]],
  ['addoutputlistener',['AddOutputListener',['../classSayuri_1_1UCIShell.html#ac5402601427177fad8b75a9b3bf95560',1,'Sayuri::UCIShell']]],
  ['age',['age',['../classSayuri_1_1TranspositionTable.html#a7a3ad73fb3c02bb6f1e396b5445e1c70',1,'Sayuri::TranspositionTable']]],
  ['aspiration_5fwindows_5fdelta',['aspiration_windows_delta',['../classSayuri_1_1SearchParams.html#a3e969417516c3ac4b6c183b24b6ea76a',1,'Sayuri::SearchParams::aspiration_windows_delta() const '],['../classSayuri_1_1SearchParams.html#ab7e879875cf05ac11508d049219bc91b',1,'Sayuri::SearchParams::aspiration_windows_delta(int delta)']]],
  ['aspiration_5fwindows_5flimit_5fdepth',['aspiration_windows_limit_depth',['../classSayuri_1_1SearchParams.html#aeda313a1f70a60685a390ef9462227b2',1,'Sayuri::SearchParams::aspiration_windows_limit_depth() const '],['../classSayuri_1_1SearchParams.html#a76b8d131f032cb78b5255e71dd98047d',1,'Sayuri::SearchParams::aspiration_windows_limit_depth(int depth)']]],
  ['attack_5fvalue_5ftable',['attack_value_table',['../classSayuri_1_1EvalParams.html#a5d753c7f1b3c882c3330c64c6fe78197',1,'Sayuri::EvalParams::attack_value_table() const)[NUM_PIECE_TYPES]'],['../classSayuri_1_1EvalParams.html#a1e983934b4e9b278e30378a7abd922d7',1,'Sayuri::EvalParams::attack_value_table(const double(&amp;table)[NUM_PIECE_TYPES][NUM_PIECE_TYPES])']]]
];
