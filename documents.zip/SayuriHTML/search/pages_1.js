var searchData=
[
  ['how_20to_20use_20sayuri_20as_20static_20library',['How to use Sayuri as static library',['../md_use_as_static_library-en.html',1,'']]]
];
