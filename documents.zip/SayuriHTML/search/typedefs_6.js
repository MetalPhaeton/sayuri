var searchData=
[
  ['rank',['Rank',['../namespaceSayuri.html#ad7c77fd498e376906722f84d95eddb75',1,'Sayuri']]]
];
