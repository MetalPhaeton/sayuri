var searchData=
[
  ['scoretype',['ScoreType',['../namespaceSayuri.html#a3a66f2893e3cf5ad92bcc22286da7c34',1,'Sayuri']]]
];
