var searchData=
[
  ['killer_5fstack',['killer_stack',['../classSayuri_1_1ChessEngine.html#ac7464c5ea227c7038f186580df40e223',1,'Sayuri::ChessEngine']]],
  ['king',['king',['../classSayuri_1_1ChessEngine.html#aaa6618020128b2aee1181a81891f5a60',1,'Sayuri::ChessEngine::king()'],['../classSayuri_1_1PositionRecord.html#a66c2a13740d1a282dfd8c99a0d7b1fac',1,'Sayuri::PositionRecord::king()']]]
];
