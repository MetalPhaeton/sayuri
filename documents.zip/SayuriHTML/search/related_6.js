var searchData=
[
  ['transpositiontable',['TranspositionTable',['../classSayuri_1_1TTEntry.html#a239bd76fb7657a46649aede59fc388a2',1,'Sayuri::TTEntry']]]
];
