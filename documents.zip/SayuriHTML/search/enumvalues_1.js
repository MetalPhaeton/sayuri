var searchData=
[
  ['beta',['BETA',['../namespaceSayuri.html#a3a66f2893e3cf5ad92bcc22286da7c34a36b84f8e3fba5bf993e3ba352d62d146',1,'Sayuri']]]
];
