var searchData=
[
  ['all',['ALL',['../namespaceSayuri.html#a38eace0fcb969cf644905fc3ff641791a5fb1f955b45e38e31789286a1790398d',1,'Sayuri']]],
  ['alpha',['ALPHA',['../namespaceSayuri.html#a3a66f2893e3cf5ad92bcc22286da7c34a002101f8725e5c78d9f30d87f3fa4c87',1,'Sayuri']]]
];
