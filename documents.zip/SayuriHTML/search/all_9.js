var searchData=
[
  ['job',['Job',['../classSayuri_1_1Job.html',1,'Sayuri']]],
  ['job',['Job',['../classSayuri_1_1Job.html#a018523eb4286cd5ceb8279bab3906834',1,'Sayuri::Job::Job()'],['../classSayuri_1_1Job.html#af0d37afe7490f22c6e1ea0c4bc944769',1,'Sayuri::Job::Job(const Job &amp;job)'],['../classSayuri_1_1Job.html#aba0bf3155333d05b7a59d7f9731c5765',1,'Sayuri::Job::Job(Job &amp;&amp;job)']]],
  ['job_2ecpp',['job.cpp',['../job_8cpp.html',1,'']]],
  ['job_2eh',['job.h',['../job_8h.html',1,'']]],
  ['job_5fptr_5f',['job_ptr_',['../classSayuri_1_1HelperQueue.html#a03737b37d542139b40896bf01ec9fe42',1,'Sayuri::HelperQueue']]],
  ['job_5ftable_5f',['job_table_',['../classSayuri_1_1ChessEngine.html#a197c8c14759ad6bc79ba39078287686b',1,'Sayuri::ChessEngine']]]
];
