var searchData=
[
  ['fen',['FEN',['../classSayuri_1_1FEN.html',1,'Sayuri']]]
];
