var searchData=
[
  ['queen_5fmove_5f',['queen_move_',['../classSayuri_1_1Util.html#ac7c47fdad2a473f633f7f7359c269d43',1,'Sayuri::Util']]]
];
