var searchData=
[
  ['genmovetype',['GenMoveType',['../namespaceSayuri.html#a38eace0fcb969cf644905fc3ff641791',1,'Sayuri']]]
];
