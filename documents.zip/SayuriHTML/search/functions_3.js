var searchData=
[
  ['debugmain',['DebugMain',['../namespaceSayuri.html#a93284b4eaa50272004abfb5831363c95',1,'Sayuri']]],
  ['defense_5fvalue_5ftable',['defense_value_table',['../classSayuri_1_1EvalParams.html#a39fdc8236a06296610fecdd1ae60c58f',1,'Sayuri::EvalParams::defense_value_table() const)[NUM_PIECE_TYPES]'],['../classSayuri_1_1EvalParams.html#a318fb87c1984543cac7195a5715fd640',1,'Sayuri::EvalParams::defense_value_table(const double(&amp;table)[NUM_PIECE_TYPES][NUM_PIECE_TYPES])']]],
  ['depth',['depth',['../classSayuri_1_1TTEntry.html#a8c44bc4c5915c8063c4d181db4ae0e88',1,'Sayuri::TTEntry']]]
];
