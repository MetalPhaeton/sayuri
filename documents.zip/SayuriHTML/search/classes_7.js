var searchData=
[
  ['sayurierror',['SayuriError',['../classSayuri_1_1SayuriError.html',1,'Sayuri']]],
  ['searchparams',['SearchParams',['../classSayuri_1_1SearchParams.html',1,'Sayuri']]],
  ['sharedstruct',['SharedStruct',['../structSayuri_1_1ChessEngine_1_1SharedStruct.html',1,'Sayuri::ChessEngine']]],
  ['stopwatch',['StopWatch',['../classSayuri_1_1StopWatch.html',1,'Sayuri']]]
];
