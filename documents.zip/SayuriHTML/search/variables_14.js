var searchData=
[
  ['uci_5fcommand_5f',['uci_command_',['../classSayuri_1_1UCIShell.html#a043a97f2451554eff3233386e9566432',1,'Sayuri::UCIShell']]],
  ['uci_5fdefault_5fanalyse_5fmode',['UCI_DEFAULT_ANALYSE_MODE',['../namespaceSayuri.html#a3c3875143f8b106afeb401ff44cf0be7',1,'Sayuri']]],
  ['uci_5fdefault_5fponder',['UCI_DEFAULT_PONDER',['../namespaceSayuri.html#ad765e7a35cd32c0754eea39b5808eb69',1,'Sayuri']]],
  ['uci_5fdefault_5ftable_5fsize',['UCI_DEFAULT_TABLE_SIZE',['../namespaceSayuri.html#a69a1ae58dc518fece3e1cf77dabfd19e',1,'Sayuri']]],
  ['uci_5fdefault_5fthreads',['UCI_DEFAULT_THREADS',['../namespaceSayuri.html#a69d93432613107d0ee028374f024eb34',1,'Sayuri']]],
  ['uci_5fmax_5ftable_5fsize',['UCI_MAX_TABLE_SIZE',['../namespaceSayuri.html#ae0c825595a5b8bd1755c529f68a8f619',1,'Sayuri']]],
  ['uci_5fmax_5fthreads',['UCI_MAX_THREADS',['../namespaceSayuri.html#a572f25e886b17cfa98017931a33ac7bd',1,'Sayuri']]],
  ['uci_5fmin_5ftable_5fsize',['UCI_MIN_TABLE_SIZE',['../namespaceSayuri.html#a3a2fe3d7cb9239d71e25a659894c995c',1,'Sayuri']]]
];
