var searchData=
[
  ['weight',['Weight',['../classSayuri_1_1Weight.html',1,'Sayuri']]]
];
