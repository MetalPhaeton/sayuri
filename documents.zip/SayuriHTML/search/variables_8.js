var searchData=
[
  ['job_5fptr_5f',['job_ptr_',['../classSayuri_1_1HelperQueue.html#a03737b37d542139b40896bf01ec9fe42',1,'Sayuri::HelperQueue']]],
  ['job_5ftable_5f',['job_table_',['../classSayuri_1_1ChessEngine.html#a197c8c14759ad6bc79ba39078287686b',1,'Sayuri::ChessEngine']]]
];
