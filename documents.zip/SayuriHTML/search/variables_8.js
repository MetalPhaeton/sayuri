var searchData=
[
  ['i_5fdepth_5f',['i_depth_',['../structSayuri_1_1ChessEngine_1_1SharedStruct.html#a4bca00c98ddfb73027eb2dfbccc498bd',1,'Sayuri::ChessEngine::SharedStruct']]],
  ['id_5fauthor',['ID_AUTHOR',['../namespaceSayuri.html#a698d47fa0b0567306b69789cef466fb4',1,'Sayuri']]],
  ['id_5fname',['ID_NAME',['../namespaceSayuri.html#af0eba75e768d8310b39854454a0bda50',1,'Sayuri']]],
  ['iid_5flimit_5fdepth_5f',['iid_limit_depth_',['../classSayuri_1_1SearchParams.html#a5d2ef8be270389ab6f72b09b3fb12591',1,'Sayuri::SearchParams']]],
  ['iid_5fsearch_5fdepth_5f',['iid_search_depth_',['../classSayuri_1_1SearchParams.html#ae1e1cf043cd1369a471ac74db85fb905',1,'Sayuri::SearchParams']]],
  ['iid_5fstack_5f',['iid_stack_',['../structSayuri_1_1ChessEngine_1_1SharedStruct.html#a97b3836256f0a88490c6c1c6e3299b07',1,'Sayuri::ChessEngine::SharedStruct']]],
  ['infinite_5fthinking_5f',['infinite_thinking_',['../structSayuri_1_1ChessEngine_1_1SharedStruct.html#ae691a311156e8d1871427cbddd54165d',1,'Sayuri::ChessEngine::SharedStruct']]],
  ['is_5fchecked_5f',['is_checked_',['../classSayuri_1_1Job.html#a3f0219a378f20611724f9626aece42c0',1,'Sayuri::Job']]],
  ['is_5fjob_5fended_5f',['is_job_ended_',['../classSayuri_1_1ChessEngine.html#a937bf6d4a2eb1603e76c6b24918d507f',1,'Sayuri::ChessEngine']]],
  ['is_5fnull_5fsearching_5f',['is_null_searching_',['../classSayuri_1_1ChessEngine.html#a9c0263240cb219b66804754dd71726b2',1,'Sayuri::ChessEngine::is_null_searching_()'],['../classSayuri_1_1Job.html#a54db0b050b89681483356f05a9659f6d',1,'Sayuri::Job::is_null_searching_()']]],
  ['is_5froot_5fclient_5fwaiting_5f',['is_root_client_waiting_',['../classSayuri_1_1HelperQueue.html#a7beb20a3279d8eccacc57d95360a44e1',1,'Sayuri::HelperQueue']]],
  ['iso_5fpawn_5fmask_5f',['iso_pawn_mask_',['../classSayuri_1_1Evaluator.html#a98631894b0883d540c63935925f4d9e9',1,'Sayuri::Evaluator']]],
  ['iso_5fpawn_5fvalue_5f',['iso_pawn_value_',['../classSayuri_1_1Evaluator.html#a2cc3abfb279e943b5883d1480fb66a96',1,'Sayuri::Evaluator']]]
];
