var searchData=
[
  ['queen_5fmove_5f',['queen_move_',['../classSayuri_1_1Util.html#ac7c47fdad2a473f633f7f7359c269d43',1,'Sayuri::Util']]],
  ['quiesce',['Quiesce',['../classSayuri_1_1ChessEngine.html#a3482c18b1bbe54cfd60b5fbc33a0a160',1,'Sayuri::ChessEngine']]]
];
