var searchData=
[
  ['customize_20of_20evaluation_20function',['Customize of evaluation function',['../md_customize_eval_params-en.html',1,'']]],
  ['customize_20of_20search_20algorithm',['Customize of search algorithm',['../md_customize_search_params-en.html',1,'']]]
];
