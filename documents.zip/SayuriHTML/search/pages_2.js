var searchData=
[
  ['readme',['README',['../md_readme.html',1,'']]],
  ['readme',['README',['../md_readme-en.html',1,'']]]
];
