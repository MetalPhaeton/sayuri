var searchData=
[
  ['opposite_5fside',['OPPOSITE_SIDE',['../chess__util_8h.html#a91bae1b01bb6ba6be2743213b1658e74',1,'chess_util.h']]]
];
