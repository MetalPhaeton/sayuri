var searchData=
[
  ['bitboard',['Bitboard',['../namespaceSayuri.html#a8ec202eb4942f1adbcfb778141bd9b1a',1,'Sayuri']]]
];
