var searchData=
[
  ['transpositiontable',['TranspositionTable',['../classSayuri_1_1TranspositionTable.html',1,'Sayuri']]],
  ['ttentry',['TTEntry',['../classSayuri_1_1TTEntry.html',1,'Sayuri']]]
];
