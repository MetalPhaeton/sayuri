var searchData=
[
  ['to_5fhistory',['TO_HISTORY',['../chess__util_8h.html#ab30672f0f95ab69e75130701c752400e',1,'chess_util.h']]]
];
