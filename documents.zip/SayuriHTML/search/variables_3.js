var searchData=
[
  ['d1',['D1',['../namespaceSayuri.html#a02435cf1a4cb38865341731c66cc2ca0',1,'Sayuri']]],
  ['d2',['D2',['../namespaceSayuri.html#a82ec13df6370c272c7e78cd11fd576eb',1,'Sayuri']]],
  ['d3',['D3',['../namespaceSayuri.html#aef50b7c50f703375237d089b7a91847a',1,'Sayuri']]],
  ['d4',['D4',['../namespaceSayuri.html#a2c26cf73c38ea49c8eb51b1bb2bce40d',1,'Sayuri']]],
  ['d5',['D5',['../namespaceSayuri.html#a004670173a671da04790d055c40f354e',1,'Sayuri']]],
  ['d6',['D6',['../namespaceSayuri.html#a0712fac887a6529a0797c24f4e2e6a19',1,'Sayuri']]],
  ['d7',['D7',['../namespaceSayuri.html#a9f28d9f8d1c141f6431a067c5cd1eac4',1,'Sayuri']]],
  ['d8',['D8',['../namespaceSayuri.html#affe23a8d0cd412f8133c17259d246e2e',1,'Sayuri']]],
  ['defense_5fvalue_5f',['defense_value_',['../classSayuri_1_1Evaluator.html#a7aa57eb4fa1e42d676f14a3aa9441e89',1,'Sayuri::Evaluator']]],
  ['defense_5fvalue_5ftable_5f',['defense_value_table_',['../classSayuri_1_1EvalParams.html#a810ba3b8815d5d03b48f043a0f633674',1,'Sayuri::EvalParams']]],
  ['delta_5f',['delta_',['../classSayuri_1_1Job.html#ac2ddc824bb5c9c00e9cb69d33edc41ab',1,'Sayuri::Job']]],
  ['depth_5f',['depth_',['../classSayuri_1_1Job.html#a2ba2c8d78b32d2a02a1fbefa8c641b1e',1,'Sayuri::Job::depth_()'],['../classSayuri_1_1TTEntry.html#a86077076789de09134f12c99b2764400',1,'Sayuri::TTEntry::depth_()']]],
  ['development_5fvalue_5f',['development_value_',['../classSayuri_1_1Evaluator.html#a3325611224e17cc0315999820dbe3304',1,'Sayuri::Evaluator']]],
  ['dist_5f',['dist_',['../classSayuri_1_1Util.html#a647f1b90de1ba5c0f7399f3863246b44',1,'Sayuri::Util']]],
  ['double_5fpawn_5fvalue_5f',['double_pawn_value_',['../classSayuri_1_1Evaluator.html#a0856af0aa202db6d204de4b79a6da023',1,'Sayuri::Evaluator']]]
];
