var searchData=
[
  ['defense',['DEFENSE',['../classSayuri_1_1Evaluator.html#afa81b44b4d99a7eae063a4aabe6b2df9',1,'Sayuri::Evaluator']]],
  ['defense_5fvalue_5ftable_5f',['defense_value_table_',['../classSayuri_1_1EvalParams.html#a810ba3b8815d5d03b48f043a0f633674',1,'Sayuri::EvalParams']]],
  ['delta_5f',['delta_',['../classSayuri_1_1Job.html#ac2ddc824bb5c9c00e9cb69d33edc41ab',1,'Sayuri::Job']]],
  ['depth_5f',['depth_',['../classSayuri_1_1Job.html#a2ba2c8d78b32d2a02a1fbefa8c641b1e',1,'Sayuri::Job']]],
  ['depth_5fmask',['DEPTH_MASK',['../classSayuri_1_1TTEntry.html#a27155b230096174743ad7806ae1b8683',1,'Sayuri::TTEntry']]],
  ['depth_5fshift',['DEPTH_SHIFT',['../classSayuri_1_1TTEntry.html#a42869ea2936f3aa0519e4a9c2f00c9cc',1,'Sayuri::TTEntry']]],
  ['development',['DEVELOPMENT',['../classSayuri_1_1Evaluator.html#ac92b0a837761227da5b097cf50e0c09b',1,'Sayuri::Evaluator']]],
  ['dist_5f',['dist_',['../classSayuri_1_1Util.html#a647f1b90de1ba5c0f7399f3863246b44',1,'Sayuri::Util']]],
  ['double_5fpawn',['DOUBLE_PAWN',['../classSayuri_1_1Evaluator.html#a26ba50f322d84ffb6bf0e549430f4a9c',1,'Sayuri::Evaluator']]]
];
