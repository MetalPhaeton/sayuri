var searchData=
[
  ['evaluator',['Evaluator',['../classSayuri_1_1ChessEngine.html#a4ceea777a33ef19332d271c60d245f1f',1,'Sayuri::ChessEngine::Evaluator()'],['../classSayuri_1_1EvalParams.html#a4ceea777a33ef19332d271c60d245f1f',1,'Sayuri::EvalParams::Evaluator()']]]
];
