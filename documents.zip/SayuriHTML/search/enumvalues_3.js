var searchData=
[
  ['exact',['EXACT',['../namespaceSayuri.html#a3a66f2893e3cf5ad92bcc22286da7c34ac41e056424136b6e8c4e23dd6326efa1',1,'Sayuri']]]
];
