var searchData=
[
  ['helperqueue',['HelperQueue',['../classSayuri_1_1HelperQueue.html',1,'Sayuri']]]
];
