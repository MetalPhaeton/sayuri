var searchData=
[
  ['addorsub',['AddOrSub',['../classSayuri_1_1ChessEngine.html#a2053e9162d72f0a53d432a9361062c31',1,'Sayuri::ChessEngine::AddOrSub()'],['../classSayuri_1_1Evaluator.html#a2053e9162d72f0a53d432a9361062c31',1,'Sayuri::Evaluator::AddOrSub()'],['../classSayuri_1_1EvalParams.html#a2053e9162d72f0a53d432a9361062c31',1,'Sayuri::EvalParams::AddOrSub()']]]
];
