var searchData=
[
  ['castling',['Castling',['../namespaceSayuri.html#a4beec475cd1436aebcd6b66e49ffbc8a',1,'Sayuri']]],
  ['commandargs',['CommandArgs',['../classSayuri_1_1UCICommand.html#a8c7cfa8994948d14964a55a8a7f38e1b',1,'Sayuri::UCICommand']]]
];
