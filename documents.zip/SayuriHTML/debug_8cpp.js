var debug_8cpp =
[
    [ "DebugMain", "debug_8cpp.html#a93284b4eaa50272004abfb5831363c95", null ],
    [ "PrintBitboard", "debug_8cpp.html#a89990893f49ccaf475cd20668af5c916", null ],
    [ "PrintEvalResult", "debug_8cpp.html#a3cc70925184e5b26fa97d4930deee74c", null ],
    [ "PrintMove", "debug_8cpp.html#abc3848072ec6b69afedc7d1099a23d4a", null ],
    [ "PrintPosition", "debug_8cpp.html#a0e58bce33e0b9d5e27abbd0b1e56be97", null ],
    [ "PrintPositionRecord", "debug_8cpp.html#ae18db4e67b3a6a1e94ebdefbe1ab6119", null ]
];