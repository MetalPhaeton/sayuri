var chess__util_8h =
[
    [ "Util", "classSayuri_1_1Util.html", "classSayuri_1_1Util" ],
    [ "MAX", "chess__util_8h.html#afa99ec4acc4ecb2dc3c2d05da15d0e3f", null ],
    [ "MIN", "chess__util_8h.html#a3acffbd305ee72dcd4593c0d8af64a4f", null ],
    [ "OPPOSITE_SIDE", "chess__util_8h.html#a91bae1b01bb6ba6be2743213b1658e74", null ],
    [ "TO_HISTORY", "chess__util_8h.html#ab30672f0f95ab69e75130701c752400e", null ]
];