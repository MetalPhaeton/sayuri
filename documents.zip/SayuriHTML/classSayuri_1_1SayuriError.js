var classSayuri_1_1SayuriError =
[
    [ "SayuriError", "classSayuri_1_1SayuriError.html#a635c06a3bfd4aec6b14ffcf6b8c2c616", null ],
    [ "SayuriError", "classSayuri_1_1SayuriError.html#aef18df2637bf3437eb259fdd838177ee", null ]
];