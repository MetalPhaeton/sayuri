var structSayuri_1_1GenBitboards_3_01PSide_00_01PAWN_01_4 =
[
    [ "F", "structSayuri_1_1GenBitboards_3_01PSide_00_01PAWN_01_4.html#a0165e97a5d61e2800b4cf9dbe779fc5e", null ]
];