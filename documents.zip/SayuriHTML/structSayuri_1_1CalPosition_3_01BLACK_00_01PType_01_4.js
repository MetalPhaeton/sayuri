var structSayuri_1_1CalPosition_3_01BLACK_00_01PType_01_4 =
[
    [ "F", "structSayuri_1_1CalPosition_3_01BLACK_00_01PType_01_4.html#a5d43178627a4e23b8d00839e50832880", null ]
];