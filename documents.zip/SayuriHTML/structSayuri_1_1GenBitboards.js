var structSayuri_1_1GenBitboards =
[
    [ "F", "structSayuri_1_1GenBitboards.html#a4d6bc77e601c59da3817d432eaa23fbf", null ]
];