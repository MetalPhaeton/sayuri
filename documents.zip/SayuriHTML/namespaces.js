var namespaces =
[
    [ "Sayuri", "namespaceSayuri.html", null ]
];