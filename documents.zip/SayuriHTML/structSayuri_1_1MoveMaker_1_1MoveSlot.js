var structSayuri_1_1MoveMaker_1_1MoveSlot =
[
    [ "move_", "structSayuri_1_1MoveMaker_1_1MoveSlot.html#a640ade33996dd9eec41957946d0e00cb", null ],
    [ "score_", "structSayuri_1_1MoveMaker_1_1MoveSlot.html#aa0f78e53e982b0f9cee815a1c91afcd8", null ]
];