var structSayuri_1_1GenPawnBitboard =
[
    [ "F", "structSayuri_1_1GenPawnBitboard.html#aa08cb6211b3446ad5cdb30d646271e7a", null ]
];