var structSayuri_1_1UCICommand_1_1CommandFunction =
[
    [ "command_name_", "structSayuri_1_1UCICommand_1_1CommandFunction.html#ab5d17d819909f6da6e72e45cc52a5e7e", null ],
    [ "func_", "structSayuri_1_1UCICommand_1_1CommandFunction.html#a44d447192d8ae8ded6bc3b49b38a4464", null ],
    [ "subcommand_name_vec_", "structSayuri_1_1UCICommand_1_1CommandFunction.html#af83de60ee725eec865092d3a7382a66f", null ]
];