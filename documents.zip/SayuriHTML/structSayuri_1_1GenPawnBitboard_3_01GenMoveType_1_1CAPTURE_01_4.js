var structSayuri_1_1GenPawnBitboard_3_01GenMoveType_1_1CAPTURE_01_4 =
[
    [ "F", "structSayuri_1_1GenPawnBitboard_3_01GenMoveType_1_1CAPTURE_01_4.html#ae1146f1adbdf121795fb57f83960ed15", null ]
];