var structSayuri_1_1GenPawnBitboard_3_01GenMoveType_1_1NON__CAPTURE_01_4 =
[
    [ "F", "structSayuri_1_1GenPawnBitboard_3_01GenMoveType_1_1NON__CAPTURE_01_4.html#af492fd28b4597e70f053dba59ec66e7b", null ]
];