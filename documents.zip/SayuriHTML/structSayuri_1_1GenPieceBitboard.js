var structSayuri_1_1GenPieceBitboard =
[
    [ "F", "structSayuri_1_1GenPieceBitboard.html#a3656ddcf6fdffd68e55b2dfa662d8c19", null ]
];