var structSayuri_1_1AddOrSub_3_01WHITE_01_4 =
[
    [ "F", "structSayuri_1_1AddOrSub_3_01WHITE_01_4.html#a74bb183b6aec3567e3731cfcb92eafb9", null ]
];