var structSayuri_1_1GenKingBitboard =
[
    [ "F", "structSayuri_1_1GenKingBitboard.html#a3faa1a66d0ec140141bc861d77f20909", null ]
];